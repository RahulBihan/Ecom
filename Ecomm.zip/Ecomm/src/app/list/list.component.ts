import { Component, OnInit } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { CartService } from '../services/cart.service';
@Component({
  selector: 'app-list',
  templateUrl: './list.component.html',
  styleUrls: ['./list.component.scss']
})
export class ListComponent implements OnInit {
items : any;

  constructor(
    private http: HttpClient,
    private cartservice: CartService
    ) {
      
     }

  ngOnInit(): void {
    this.getItems().subscribe( x => {
      this.items = x.data;
      // console.log("ov data",this.cartservice.emptycart)
      })
     }

     getItems() {
      return this.http.get<any>('https://www.mocky.io/v2/5eda4003330000740079ea60');
    }
    addToCart(id)
    {
      
      this.cartservice.setData(id);
    }

}
