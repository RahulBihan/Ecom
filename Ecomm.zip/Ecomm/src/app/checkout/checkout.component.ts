import { Component, OnInit } from '@angular/core';
import { CartService } from '../services/cart.service';
import {Router } from '@angular/router';

@Component({
  selector: 'app-checkout',
  templateUrl: './checkout.component.html',
  styleUrls: ['./checkout.component.scss']
})
export class CheckoutComponent implements OnInit {
checkoutData:any=[];
total:number = 0;
  constructor(private cartservice: CartService , private router:Router) { }

  ngOnInit(): void {
    this.checkoutData = this.cartservice.dataItem;
    for(let i = 0; i < this.checkoutData.length; i++ ){
      console.log("checkout",this.checkoutData)
        this.total = this.total + this.checkoutData[i].subtotal;
    }
  }
  buy()
  { 
   alert("Order Placed Successfully");
   this.cartservice.subject.next([]);
   this.cartservice.emptyCarts();
    this.router.navigate(['/']);
  }
}
