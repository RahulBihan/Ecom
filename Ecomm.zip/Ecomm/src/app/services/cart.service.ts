import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';
import * as Rx from "rxjs";

@Injectable({
  providedIn: 'root'
})
export class CartService {
dataItem :any=[];
updtedCartData: any=[];
 subject = new Rx.BehaviorSubject(null);
  constructor() { }

  getData() : Observable<any>{
    return this.dataItem;
  }
  setData(id){
    let x = this.dataItem.filter(x => x.id === id.id)
    if(x.length === 0){
      this.dataItem.push(id);
      this.subject.next(this.dataItem);
    } else{
      alert('product Exist')
    }
  }
  setdatacart(items){
    this.dataItem = [];
    this.dataItem = items;
  }

  setUpdatedCartData(data)
  {
    this.updtedCartData = data;
  }

  getUpdatedCart()
  {
    return this.updtedCartData;
  }

  emptyCarts()
  {
    this.subject.subscribe(x => {
      if(x)
      this.dataItem = x;  
    })
    this.dataItem = []
    return of (this.dataItem);
  }

}
