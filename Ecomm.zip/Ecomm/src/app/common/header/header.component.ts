import { Component, OnInit } from '@angular/core';
import { CartService } from 'src/app/services/cart.service';
import {TemplateRef } from '@angular/core';
import { BsModalService, BsModalRef } from 'ngx-bootstrap/modal';
import {Router } from '@angular/router';
@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit {
  cartData:any=[];
  modalRef: BsModalRef;
  total:number = 0;
  updatedcartData:any =[];
  constructor(private cartService:CartService ,private modalService: BsModalService , private router:Router) { 
  this.cartData = this.cartService.dataItem;
  
  }

  ngOnInit(): void {
    this.cartService.subject.subscribe(x => {
      if(x)
      this.cartData = x;
    })
      }

  openModal(template: TemplateRef<any>) {
    this.modalRef = this.modalService.show(template);
    
    this.total = 0;
    
    console.log("called", this.cartData)
    for(let i = 0; i < this.cartData.length; i++ ){
      this.cartData[i].subtotal = parseInt(this.cartData[i].price);
      this.total = this.total +this.cartData[i].subtotal;
    }
  }
delete(x){
  this.cartData = this.cartData.filter(y => y.id !== x.id);
  this.cartService.setdatacart(this.cartData)
  this.total = 0;
  for(let i = 0; i < this.cartData.length; i++ )
  {
    this.total = this.total+this.cartData[i].subtotal;
  }
  console.log("remove", this.cartData);
  //this.total = this.total - this.cartData.subtotal;
}
  checkout()
  { console.log("updd", this.cartData)
    this.cartService.subject.next(this.cartData);
    this.cartService.dataItem = this.cartData;
    this.router.navigate(['/checkout']);
   
  }
  onKey(x){
    if(x.target.value){
    for(let i = 0; i < this.cartData.length; i++ ){
      if(this.cartData[i].id == x.target.id ){
        this.total = this.total - this.cartData[i].subtotal;
        this.cartData[i].subtotal = x.target.value * parseInt(this.cartData[i].price);
        this.cartData[i].qty = x.target.value;
        this.total = this.total + this.cartData[i].subtotal;
        this.cartService.setUpdatedCartData(this.updatedcartData);
        
      }
    }
  }
  }
}
